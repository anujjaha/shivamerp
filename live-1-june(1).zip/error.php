<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<?php
if($_REQUEST['msg'] == 404 )
{
	echo "<center><h2>Data Not Saved ...Please try Again...!</h2></center>";
}
?>