<table align="center" border="2" width="60%">
<form action="#" method="POST">
	<tr>
    	<td class="search" align="right" width="90%">
        	<input type="text" name="filter" placeholder="Type Keyword" />
        </td>
        <td align="center" width="5%">
        	<input type="submit" name="search" value="Filter" />
        </td>
         <td align="center" width="5%">
        	<a href="school_list.php"> Reset </a>
        </td>
    </tr>
</form>
</table>