<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<center>
	<h1 class="home">
    	Welcome Home
    </h1>
</center>